
	    <?php defined('_JEXEC') or die( 'Restricted access' );
	    		/**
				 * @package		AdsManager
				 * @copyright	Copyright (C) 2010-2013 JoomPROD.com. All rights reserved.
				 * @license		GNU/GPL
				 */
	    		$last_cron_date=20140502;?>